Once you've played around with Nova, you might want to deploy your app for the whole world to see. 

We recommend using [Meteor Up X (MupX)](https://github.com/arunoda/meteor-up/tree/mupx) to deploy to a [Digital Ocean](http://digitalocean.com) server, along with [Compose](http://compose.io) to host your database. 

Other good alternatives include [Galaxy](http://galaxy.meteor.com/) and [Scalingo](http://scalingo.com).