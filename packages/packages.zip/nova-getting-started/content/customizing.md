If you want to learn how to customize Nova, we suggest checking out the [Read Me](https://github.com/TelescopeJS/Telescope) on GitHub. 

The first things you'll want to do are probably create a `settings.json` file to hold all your settings, and then taking a look at the sample custom package by uncommenting `my-custom-package` in `.meteor/packages`.