### Welcome to Nova!

If you're reading this, it means you've successfully got Nova to run. 

To make your first run a bit easier, we've taken the liberty of preloading your brand new app with a few posts that will walk you through your first steps with Nova.

### Creating An Account

The first thing you'll need to do is create your account. Since this will be the first ever account created in this app, it will automatically be assigned admin rights, and you'll then be able to access Nova's settings panel.

Click the “Log In” link in the top menu and come back here once you're done!

### Start Posting!

You're now all set to start using Nova. Check out the other posts for more information, or just start posting!
